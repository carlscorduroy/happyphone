"""Cryptographic operations using PyNaCl (libsodium)"""

import secrets
import hashlib
from dataclasses import dataclass
from typing import Optional

from nacl.public import PrivateKey, PublicKey, Box
from nacl.encoding import Base64Encoder, RawEncoder
from nacl.pwhash import argon2id
from nacl.hash import blake2b
from nacl.utils import random as nacl_random
from nacl.secret import SecretBox
import nacl.bindings

from .config import ARGON2_OPS_LIMIT, ARGON2_MEM_LIMIT

# Emoji set for fingerprints
FINGERPRINT_EMOJIS = [
    '🔐', '🦊', '🌲', '🎸', '🚀', '🌙', '🎨', '🦋',
    '🌺', '🎭', '🦉', '🌊', '🎪', '🦁', '🌴', '🎯',
    '🦄', '🌈', '🎵', '🦚', '🌻', '🎲', '🦩', '🌸',
    '🎡', '🦔', '🌵', '🎠', '🦜', '🌾', '🎢', '🦝'
]


@dataclass
class Identity:
    """User's cryptographic identity"""
    user_id: str
    public_key: bytes  # 32 bytes
    private_key: bytes  # 32 bytes
    display_name: str

    def public_key_b64(self) -> str:
        return Base64Encoder.encode(self.public_key).decode('ascii')

    def get_fingerprint(self) -> list[str]:
        """Get emoji fingerprint of public key"""
        return get_fingerprint(self.public_key)


@dataclass
class Contact:
    """A verified contact"""
    user_id: str
    public_key: bytes
    display_name: str
    pet_name: str
    trust_tier: str  # 'family', 'business', 'other'
    verified: bool

    def public_key_b64(self) -> str:
        return Base64Encoder.encode(self.public_key).decode('ascii')


@dataclass
class EncryptedPayload:
    """Encrypted message format"""
    ephemeral_public: bytes
    nonce: bytes
    ciphertext: bytes

    def to_dict(self) -> dict:
        return {
            'ephemeralPublic': Base64Encoder.encode(self.ephemeral_public).decode('ascii'),
            'nonce': Base64Encoder.encode(self.nonce).decode('ascii'),
            'ciphertext': Base64Encoder.encode(self.ciphertext).decode('ascii'),
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'EncryptedPayload':
        return cls(
            ephemeral_public=Base64Encoder.decode(data['ephemeralPublic'].encode('ascii')),
            nonce=Base64Encoder.decode(data['nonce'].encode('ascii')),
            ciphertext=Base64Encoder.decode(data['ciphertext'].encode('ascii')),
        )


def generate_user_id() -> str:
    """Generate a short, memorable user ID"""
    chars = 'abcdefghjkmnpqrstuvwxyz23456789'  # No confusing chars
    return ''.join(secrets.choice(chars) for _ in range(6))


def create_identity(display_name: str) -> Identity:
    """Generate a new identity with keypair"""
    private_key = PrivateKey.generate()
    public_key = private_key.public_key

    return Identity(
        user_id=generate_user_id(),
        public_key=bytes(public_key),
        private_key=bytes(private_key),
        display_name=display_name,
    )


def get_fingerprint(public_key: bytes) -> list[str]:
    """Generate emoji fingerprint from public key"""
    hash_bytes = blake2b(public_key, digest_size=32, encoder=RawEncoder)
    emojis = []
    for i in range(8):
        idx = hash_bytes[i] % len(FINGERPRINT_EMOJIS)
        emojis.append(FINGERPRINT_EMOJIS[idx])
    return emojis


def get_shared_fingerprint(public_key1: bytes, public_key2: bytes) -> list[str]:
    """Generate shared fingerprint for two users (for call verification)"""
    # Sort keys to ensure same result regardless of order
    if public_key1 < public_key2:
        combined = public_key1 + public_key2
    else:
        combined = public_key2 + public_key1

    combined_hash = blake2b(combined, digest_size=32, encoder=RawEncoder)
    return get_fingerprint(combined_hash)


def encrypt_message(plaintext: str, recipient_public_key: bytes) -> EncryptedPayload:
    """Encrypt a message for a recipient using ephemeral keypair"""
    # Generate ephemeral keypair for forward secrecy
    ephemeral_private = PrivateKey.generate()
    ephemeral_public = ephemeral_private.public_key

    # Create box for encryption
    recipient_key = PublicKey(recipient_public_key)
    box = Box(ephemeral_private, recipient_key)

    # Encrypt
    plaintext_bytes = plaintext.encode('utf-8')
    encrypted = box.encrypt(plaintext_bytes)

    return EncryptedPayload(
        ephemeral_public=bytes(ephemeral_public),
        nonce=encrypted.nonce,
        ciphertext=encrypted.ciphertext,
    )


def decrypt_message(payload: EncryptedPayload, recipient_private_key: bytes) -> str:
    """Decrypt a message using recipient's private key"""
    private_key = PrivateKey(recipient_private_key)
    ephemeral_public = PublicKey(payload.ephemeral_public)

    box = Box(private_key, ephemeral_public)
    plaintext_bytes = box.decrypt(payload.ciphertext, payload.nonce)

    return plaintext_bytes.decode('utf-8')


def derive_key_from_keyphrase(keyphrase: str, salt: bytes) -> bytes:
    """Derive encryption key from keyphrase using Argon2id"""
    return argon2id.kdf(
        size=32,
        password=keyphrase.lower().strip().encode('utf-8'),
        salt=salt,
        opslimit=ARGON2_OPS_LIMIT,
        memlimit=ARGON2_MEM_LIMIT,
    )


def generate_challenge() -> tuple[bytes, bytes]:
    """Generate challenge and salt for keyphrase verification"""
    challenge = nacl_random(32)
    salt = nacl_random(16)  # Argon2 salt size
    return challenge, salt


def respond_to_challenge(challenge: bytes, salt: bytes, keyphrase: str) -> bytes:
    """Create HMAC response to challenge using derived key"""
    derived_key = derive_key_from_keyphrase(keyphrase, salt)
    # Use BLAKE2b as HMAC
    return blake2b(challenge, key=derived_key, digest_size=32, encoder=RawEncoder)


def verify_challenge(challenge: bytes, salt: bytes, response: bytes, keyphrase: str) -> bool:
    """Verify a challenge response"""
    expected = respond_to_challenge(challenge, salt, keyphrase)
    return secrets.compare_digest(expected, response)


def public_key_from_b64(b64_key: str) -> bytes:
    """Decode base64 public key"""
    return Base64Encoder.decode(b64_key.encode('ascii'))


def public_key_to_b64(public_key: bytes) -> str:
    """Encode public key to base64"""
    return Base64Encoder.encode(public_key).decode('ascii')
