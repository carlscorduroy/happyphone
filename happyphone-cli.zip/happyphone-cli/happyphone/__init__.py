"""Happy Phone - E2EE Communication CLI"""

__version__ = "0.1.0"
