"""Happy Phone CLI - Main Interface"""

import asyncio
import json
import sys
import uuid
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.layout import Layout
from prompt_toolkit import PromptSession
from prompt_toolkit.patch_stdout import patch_stdout
from nacl.encoding import Base64Encoder

from .config import SIGNALING_URL, DATA_DIR
from .crypto import (
    create_identity, encrypt_message, decrypt_message,
    generate_challenge, respond_to_challenge, verify_challenge,
    get_fingerprint, get_shared_fingerprint,
    public_key_to_b64, public_key_from_b64,
    Identity, Contact, EncryptedPayload
)
from .storage import storage, Storage
from .signaling import signaling, SignalingEvent
from .audio import VoiceCall, check_audio_dependencies

console = Console()


class HappyPhoneCLI:
    """Main CLI application"""

    def __init__(self):
        self.identity: Optional[Identity] = None
        self.contacts: dict[str, Contact] = {}  # user_id -> Contact
        self.contacts_by_name: dict[str, Contact] = {}  # lowercase pet_name -> Contact
        self.active_chat: Optional[str] = None  # user_id of active chat
        self.call: Optional[VoiceCall] = None
        self.pending_verification: dict = {}  # For keyphrase verification
        self._running = False
        self._message_queue: asyncio.Queue = asyncio.Queue()

    async def start(self):
        """Start the CLI application"""
        console.print(Panel.fit(
            "[bold green]📱 Happy Phone[/bold green]\n"
            "[dim]End-to-End Encrypted Communication[/dim]",
            border_style="green"
        ))

        # Initialize storage
        await storage.connect()

        # Load or create identity
        self.identity = await storage.get_identity()
        if not self.identity:
            await self._create_identity_flow()

        # Load contacts
        await self._load_contacts()

        # Connect to signaling server
        await self._connect()

        # Set up event handlers
        self._setup_event_handlers()

        # Start main loop
        self._running = True
        await self._main_loop()

    async def _create_identity_flow(self):
        """Interactive identity creation"""
        console.print("\n[yellow]No identity found. Let's create one.[/yellow]\n")

        session = PromptSession()
        name = await session.prompt_async("Enter your display name: ")

        self.identity = create_identity(name.strip())
        await storage.save_identity(self.identity)

        fingerprint = " ".join(self.identity.get_fingerprint())
        console.print(f"\n[green]✓ Identity created![/green]")
        console.print(f"  Your ID: [bold cyan]{self.identity.user_id}[/bold cyan]")
        console.print(f"  Fingerprint: {fingerprint}")
        console.print(f"\n  Share your ID with contacts to connect.\n")

    async def _load_contacts(self):
        """Load contacts from storage"""
        contacts = await storage.get_all_contacts()
        self.contacts = {c.user_id: c for c in contacts}
        self.contacts_by_name = {c.pet_name.lower(): c for c in contacts}

    async def _connect(self):
        """Connect to signaling server"""
        console.print(f"[dim]Connecting to {SIGNALING_URL}...[/dim]")
        try:
            await signaling.connect(self.identity)
            # Wait for registration
            await asyncio.sleep(1)
            if signaling.is_registered:
                console.print("[green]✓ Connected and registered[/green]\n")
            else:
                console.print("[yellow]⚠ Connected but not registered yet[/yellow]\n")
        except Exception as e:
            console.print(f"[red]✗ Connection failed: {e}[/red]")
            console.print("[dim]You can still view contacts and history offline.[/dim]\n")

    def _setup_event_handlers(self):
        """Set up signaling event handlers"""

        async def on_message(event: SignalingEvent):
            await self._handle_incoming_message(event)
        signaling.on('message', on_message)

        async def on_contact_request(event: SignalingEvent):
            await self._handle_contact_request(event)
        signaling.on('contact-request', on_contact_request)

        async def on_contact_response(event: SignalingEvent):
            await self._handle_contact_response(event)
        signaling.on('contact-response', on_contact_response)

        async def on_call_offer(event: SignalingEvent):
            await self._handle_call_offer(event)
        signaling.on('call-offer', on_call_offer)

        async def on_call_answer(event: SignalingEvent):
            await self._handle_call_answer(event)
        signaling.on('call-answer', on_call_answer)

        async def on_call_end(event: SignalingEvent):
            await self._handle_call_end(event)
        signaling.on('call-end', on_call_end)

    async def _handle_incoming_message(self, event: SignalingEvent):
        """Handle incoming encrypted message"""
        if not event.from_user or not event.payload:
            return

        contact = self.contacts.get(event.from_user)
        sender_name = contact.pet_name if contact else event.from_user

        try:
            payload_data = json.loads(event.payload)
            payload = EncryptedPayload.from_dict(payload_data)
            plaintext = decrypt_message(payload, self.identity.private_key)

            # Save message
            msg_id = str(uuid.uuid4())
            timestamp = int(datetime.now().timestamp() * 1000)
            await storage.save_message(
                msg_id, event.from_user, 'received', plaintext, timestamp
            )

            # Display
            verified = "✓" if contact and contact.verified else "⚠"
            console.print(f"\n[cyan][{sender_name}][/cyan] {verified}: {plaintext}")

        except Exception as e:
            console.print(f"\n[red]Failed to decrypt message from {sender_name}: {e}[/red]")

    async def _handle_contact_request(self, event: SignalingEvent):
        """Handle incoming contact verification request"""
        if not event.from_user or not event.data:
            return

        challenge = event.data.get('challenge')
        payload_str = event.data.get('payload')

        if not challenge or not payload_str:
            return

        try:
            payload = json.loads(payload_str)
            salt = payload.get('salt')
            their_public_key = payload.get('publicKey')

            if not salt or not their_public_key:
                return

            # Store for when user provides keyphrase
            self.pending_verification[event.from_user] = {
                'challenge': challenge,
                'salt': salt,
                'public_key': their_public_key,
                'direction': 'incoming',
            }

            console.print(f"\n[yellow]📨 Contact request from {event.from_user}[/yellow]")
            console.print(f"[dim]Use: add {event.from_user} <keyphrase> <name>[/dim]")

        except Exception as e:
            console.print(f"\n[red]Failed to parse contact request: {e}[/red]")

    async def _handle_contact_response(self, event: SignalingEvent):
        """Handle contact verification response"""
        if not event.from_user or not event.payload:
            return

        pending = self.pending_verification.get(event.from_user)
        if not pending or pending.get('direction') != 'outgoing':
            return

        try:
            data = json.loads(event.payload)
            response = data.get('response')
            their_public_key = data.get('publicKey')

            if not response or not their_public_key:
                return

            # Verify the response
            challenge_bytes = Base64Encoder.decode(pending['challenge'].encode())
            salt_bytes = Base64Encoder.decode(pending['salt'].encode())
            response_bytes = Base64Encoder.decode(response.encode())

            if verify_challenge(challenge_bytes, salt_bytes, response_bytes, pending['keyphrase']):
                # Success! Add contact
                contact = Contact(
                    user_id=event.from_user,
                    public_key=public_key_from_b64(their_public_key),
                    display_name=pending.get('pet_name', event.from_user),
                    pet_name=pending.get('pet_name', event.from_user),
                    trust_tier=pending.get('trust_tier', 'other'),
                    verified=True,
                )
                await storage.save_contact(contact)
                self.contacts[contact.user_id] = contact
                self.contacts_by_name[contact.pet_name.lower()] = contact

                console.print(f"\n[green]✓ Contact verified and added: {contact.pet_name}[/green]")
            else:
                console.print(f"\n[red]✗ Verification failed - keyphrase mismatch[/red]")

            del self.pending_verification[event.from_user]

        except Exception as e:
            console.print(f"\n[red]Failed to process contact response: {e}[/red]")

    async def _handle_call_offer(self, event: SignalingEvent):
        """Handle incoming call"""
        if not event.from_user:
            return

        contact = self.contacts.get(event.from_user)
        caller_name = contact.pet_name if contact else event.from_user
        verified = "✓" if contact and contact.verified else "⚠"

        console.print(f"\n[bold yellow]📞 Incoming call from {caller_name} {verified}[/bold yellow]")
        console.print("[dim]Type 'answer' to accept or 'decline' to reject[/dim]")

        # Store offer for answering
        self.pending_verification[f"call_{event.from_user}"] = event.data.get('offer')

    async def _handle_call_answer(self, event: SignalingEvent):
        """Handle call answer"""
        if not self.call or not event.data:
            return

        try:
            await self.call.handle_answer(event.data.get('answer', {}))
            console.print("[green]📞 Call connected![/green]")
        except Exception as e:
            console.print(f"[red]Call connection failed: {e}[/red]")

    async def _handle_call_end(self, event: SignalingEvent):
        """Handle call end"""
        if self.call and self.call.is_active:
            await self.call.hangup()
            console.print("\n[yellow]📞 Call ended by remote party[/yellow]")
        self.call = None

    async def _main_loop(self):
        """Main input loop"""
        session = PromptSession()

        self._print_help()

        with patch_stdout():
            while self._running:
                try:
                    prompt_text = f"[{self.identity.user_id}]> "
                    user_input = await session.prompt_async(prompt_text)

                    if user_input.strip():
                        await self._handle_command(user_input.strip())

                except KeyboardInterrupt:
                    break
                except EOFError:
                    break
                except Exception as e:
                    console.print(f"[red]Error: {e}[/red]")

        # Cleanup
        await self._shutdown()

    async def _handle_command(self, input_text: str):
        """Handle user command"""
        parts = input_text.split(maxsplit=3)
        cmd = parts[0].lower()

        if cmd == 'help':
            self._print_help()

        elif cmd == 'status':
            await self._cmd_status()

        elif cmd == 'id':
            self._cmd_id()

        elif cmd == 'contacts':
            await self._cmd_contacts()

        elif cmd == 'add':
            if len(parts) < 3:
                console.print("[yellow]Usage: add <user_id> <keyphrase> [name] [tier][/yellow]")
            else:
                user_id = parts[1]
                keyphrase = parts[2]
                name = parts[3] if len(parts) > 3 else user_id
                await self._cmd_add_contact(user_id, keyphrase, name)

        elif cmd == 'msg':
            if len(parts) < 3:
                console.print("[yellow]Usage: msg <name> <message>[/yellow]")
            else:
                name = parts[1]
                message = input_text.split(maxsplit=2)[2]
                await self._cmd_send_message(name, message)

        elif cmd == 'history':
            name = parts[1] if len(parts) > 1 else None
            await self._cmd_history(name)

        elif cmd == 'call':
            if len(parts) < 2:
                console.print("[yellow]Usage: call <name>[/yellow]")
            else:
                await self._cmd_call(parts[1])

        elif cmd == 'answer':
            await self._cmd_answer()

        elif cmd == 'decline':
            await self._cmd_decline()

        elif cmd == 'hangup':
            await self._cmd_hangup()

        elif cmd == 'delete':
            if len(parts) < 2:
                console.print("[yellow]Usage: delete <name>[/yellow]")
            else:
                await self._cmd_delete_contact(parts[1])

        elif cmd == 'reset':
            await self._cmd_reset()

        elif cmd in ('quit', 'exit', 'q'):
            self._running = False

        else:
            console.print(f"[yellow]Unknown command: {cmd}. Type 'help' for commands.[/yellow]")

    def _print_help(self):
        """Print help message"""
        help_text = """
[bold]Commands:[/bold]
  [cyan]status[/cyan]                    Show connection status
  [cyan]id[/cyan]                        Show your user ID and fingerprint
  [cyan]contacts[/cyan]                  List all contacts
  [cyan]add[/cyan] <id> <phrase> [name]  Add contact with keyphrase verification
  [cyan]msg[/cyan] <name> <text>         Send encrypted message
  [cyan]history[/cyan] [name]            Show message history
  [cyan]call[/cyan] <name>               Start voice call
  [cyan]answer[/cyan]                    Answer incoming call
  [cyan]decline[/cyan]                   Decline incoming call
  [cyan]hangup[/cyan]                    End current call
  [cyan]delete[/cyan] <name>             Delete a contact
  [cyan]reset[/cyan]                     Delete identity and all data
  [cyan]quit[/cyan]                      Exit
"""
        console.print(help_text)

    async def _cmd_status(self):
        """Show status"""
        status = "[green]Connected[/green]" if signaling.is_connected else "[red]Disconnected[/red]"
        registered = "[green]Yes[/green]" if signaling.is_registered else "[yellow]No[/yellow]"

        audio_ok, missing = check_audio_dependencies()
        audio_status = "[green]Available[/green]" if audio_ok else f"[red]Missing: {', '.join(missing)}[/red]"

        console.print(f"\n  Server: {status}")
        console.print(f"  Registered: {registered}")
        console.print(f"  Audio: {audio_status}")
        console.print(f"  Contacts: {len(self.contacts)}")
        console.print(f"  Data dir: {DATA_DIR}\n")

    def _cmd_id(self):
        """Show identity"""
        fingerprint = " ".join(self.identity.get_fingerprint())
        console.print(f"\n  User ID: [bold cyan]{self.identity.user_id}[/bold cyan]")
        console.print(f"  Name: {self.identity.display_name}")
        console.print(f"  Fingerprint: {fingerprint}")
        console.print(f"\n  [dim]Share your User ID with contacts[/dim]\n")

    async def _cmd_contacts(self):
        """List contacts"""
        if not self.contacts:
            console.print("\n[dim]No contacts yet. Use 'add' to add someone.[/dim]\n")
            return

        table = Table(title="Contacts")
        table.add_column("Name", style="cyan")
        table.add_column("ID", style="dim")
        table.add_column("Verified", style="green")
        table.add_column("Tier")

        for contact in self.contacts.values():
            verified = "✓" if contact.verified else "⚠"
            table.add_row(
                contact.pet_name,
                contact.user_id,
                verified,
                contact.trust_tier
            )

        console.print(table)

    async def _cmd_add_contact(self, user_id: str, keyphrase: str, pet_name: str):
        """Add a new contact with keyphrase verification"""
        if not signaling.is_connected:
            console.print("[red]Not connected to server[/red]")
            return

        # Check if already exists
        if user_id in self.contacts:
            console.print(f"[yellow]Contact {user_id} already exists[/yellow]")
            return

        # Check if there's a pending incoming request
        pending = self.pending_verification.get(user_id)
        if pending and pending.get('direction') == 'incoming':
            # Respond to their request
            try:
                challenge_bytes = Base64Encoder.decode(pending['challenge'].encode())
                salt_bytes = Base64Encoder.decode(pending['salt'].encode())

                response = respond_to_challenge(challenge_bytes, salt_bytes, keyphrase)
                response_b64 = Base64Encoder.encode(response).decode()

                await signaling.send_contact_response(
                    user_id,
                    response_b64,
                    json.dumps({
                        'response': response_b64,
                        'publicKey': self.identity.public_key_b64(),
                    })
                )

                # Add contact
                contact = Contact(
                    user_id=user_id,
                    public_key=public_key_from_b64(pending['public_key']),
                    display_name=pet_name,
                    pet_name=pet_name,
                    trust_tier='other',
                    verified=True,
                )
                await storage.save_contact(contact)
                self.contacts[contact.user_id] = contact
                self.contacts_by_name[contact.pet_name.lower()] = contact

                console.print(f"[green]✓ Contact added: {pet_name}[/green]")
                del self.pending_verification[user_id]
                return

            except Exception as e:
                console.print(f"[red]Failed to respond: {e}[/red]")
                return

        # Initiate new request
        console.print(f"[dim]Sending verification request to {user_id}...[/dim]")

        try:
            challenge, salt = generate_challenge()
            challenge_b64 = Base64Encoder.encode(challenge).decode()
            salt_b64 = Base64Encoder.encode(salt).decode()

            await signaling.send_contact_request(
                user_id,
                challenge_b64,
                json.dumps({
                    'salt': salt_b64,
                    'publicKey': self.identity.public_key_b64(),
                })
            )

            # Store pending verification
            self.pending_verification[user_id] = {
                'challenge': challenge_b64,
                'salt': salt_b64,
                'keyphrase': keyphrase,
                'pet_name': pet_name,
                'trust_tier': 'other',
                'direction': 'outgoing',
            }

            console.print(f"[yellow]Waiting for {user_id} to verify...[/yellow]")
            console.print(f"[dim]They need to run: add {self.identity.user_id} {keyphrase} <your_name>[/dim]")

        except Exception as e:
            console.print(f"[red]Failed to send request: {e}[/red]")

    async def _cmd_send_message(self, name: str, message: str):
        """Send encrypted message"""
        contact = self.contacts_by_name.get(name.lower())
        if not contact:
            contact = self.contacts.get(name)  # Try user_id

        if not contact:
            console.print(f"[red]Contact '{name}' not found[/red]")
            return

        if not signaling.is_connected:
            console.print("[red]Not connected to server[/red]")
            return

        try:
            # Encrypt message
            payload = encrypt_message(message, contact.public_key)

            # Send
            await signaling.send_message(contact.user_id, payload)

            # Save locally
            msg_id = str(uuid.uuid4())
            timestamp = int(datetime.now().timestamp() * 1000)
            await storage.save_message(msg_id, contact.user_id, 'sent', message, timestamp)

            console.print(f"[green]→ {contact.pet_name}:[/green] {message}")

        except Exception as e:
            console.print(f"[red]Failed to send: {e}[/red]")

    async def _cmd_history(self, name: Optional[str]):
        """Show message history"""
        if name:
            contact = self.contacts_by_name.get(name.lower())
            if not contact:
                contact = self.contacts.get(name)
            if not contact:
                console.print(f"[red]Contact '{name}' not found[/red]")
                return

            messages = await storage.get_messages(contact.user_id, limit=20)
            if not messages:
                console.print(f"[dim]No messages with {contact.pet_name}[/dim]")
                return

            console.print(f"\n[bold]Messages with {contact.pet_name}[/bold]\n")
            for msg in messages:
                direction = "→" if msg['direction'] == 'sent' else "←"
                time_str = datetime.fromtimestamp(msg['timestamp'] / 1000).strftime('%H:%M')
                console.print(f"  {time_str} {direction} {msg['content']}")
            console.print()
        else:
            console.print("[yellow]Usage: history <name>[/yellow]")

    async def _cmd_call(self, name: str):
        """Start voice call"""
        contact = self.contacts_by_name.get(name.lower())
        if not contact:
            console.print(f"[red]Contact '{name}' not found[/red]")
            return

        audio_ok, missing = check_audio_dependencies()
        if not audio_ok:
            console.print(f"[red]Audio not available. Missing: {', '.join(missing)}[/red]")
            console.print("[dim]Install with: pip install pyaudio aiortc[/dim]")
            return

        if not signaling.is_connected:
            console.print("[red]Not connected to server[/red]")
            return

        try:
            self.call = VoiceCall()
            await self.call.create_peer_connection(contact.user_id)
            await self.call.add_microphone()

            offer = await self.call.create_offer()
            await signaling.send_call_offer(contact.user_id, offer)

            console.print(f"[yellow]📞 Calling {contact.pet_name}...[/yellow]")

        except Exception as e:
            console.print(f"[red]Failed to start call: {e}[/red]")
            self.call = None

    async def _cmd_answer(self):
        """Answer incoming call"""
        # Find pending call
        call_key = None
        offer = None
        for key in list(self.pending_verification.keys()):
            if key.startswith('call_'):
                call_key = key
                offer = self.pending_verification[key]
                break

        if not offer:
            console.print("[yellow]No incoming call to answer[/yellow]")
            return

        user_id = call_key.replace('call_', '')

        try:
            self.call = VoiceCall()
            await self.call.create_peer_connection(user_id)
            await self.call.add_microphone()

            answer = await self.call.handle_offer(offer)
            await signaling.send_call_answer(user_id, answer)

            del self.pending_verification[call_key]
            console.print("[green]📞 Call connected![/green]")

        except Exception as e:
            console.print(f"[red]Failed to answer: {e}[/red]")
            self.call = None

    async def _cmd_decline(self):
        """Decline incoming call"""
        call_key = None
        for key in list(self.pending_verification.keys()):
            if key.startswith('call_'):
                call_key = key
                break

        if call_key:
            user_id = call_key.replace('call_', '')
            await signaling.send_call_end(user_id)
            del self.pending_verification[call_key]
            console.print("[yellow]Call declined[/yellow]")
        else:
            console.print("[yellow]No incoming call to decline[/yellow]")

    async def _cmd_hangup(self):
        """End current call"""
        if self.call and self.call.is_active:
            await signaling.send_call_end(self.call.remote_user_id)
            await self.call.hangup()
            self.call = None
            console.print("[yellow]📞 Call ended[/yellow]")
        else:
            console.print("[yellow]No active call[/yellow]")

    async def _cmd_delete_contact(self, name: str):
        """Delete a contact"""
        contact = self.contacts_by_name.get(name.lower())
        if not contact:
            console.print(f"[red]Contact '{name}' not found[/red]")
            return

        await storage.delete_contact(contact.user_id)
        del self.contacts[contact.user_id]
        del self.contacts_by_name[contact.pet_name.lower()]
        console.print(f"[green]✓ Contact '{contact.pet_name}' deleted[/green]")

    async def _cmd_reset(self):
        """Reset all data"""
        console.print("[yellow]This will delete your identity and all contacts![/yellow]")
        session = PromptSession()
        confirm = await session.prompt_async("Type 'yes' to confirm: ")

        if confirm.lower() == 'yes':
            await storage.delete_identity()
            console.print("[green]✓ All data deleted. Restart the app to create a new identity.[/green]")
            self._running = False
        else:
            console.print("[dim]Cancelled[/dim]")

    async def _shutdown(self):
        """Clean shutdown"""
        console.print("\n[dim]Shutting down...[/dim]")

        if self.call and self.call.is_active:
            await self.call.hangup()

        await signaling.disconnect()
        await storage.close()

        console.print("[green]Goodbye! 👋[/green]")


def main():
    """Entry point"""
    cli = HappyPhoneCLI()
    try:
        asyncio.run(cli.start())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
